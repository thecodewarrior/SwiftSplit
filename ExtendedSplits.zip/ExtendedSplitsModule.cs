﻿using Microsoft.Xna.Framework;
using Monocle;
using System;
using System.Runtime.InteropServices;

namespace Celeste.Mod.Rainbow
{
    [StructLayout(LayoutKind.Explicit)]
    public class ExtendedSplitterInfo
    {
        // These offsets leave gaps, but it makes it the math easier
        [FieldOffset(0)] private ulong __marker = 0x1100deadbeef0011;
        [FieldOffset(8)] public int ChapterDeaths;
        [FieldOffset(16)] public int LevelDeaths;
        [FieldOffset(24)] public string AreaName = "";
        [FieldOffset(32)] public string AreaSID = "";
        [FieldOffset(40)] public string LevelSet = "";
        [FieldOffset(48)] public int FeedIndex;
        [FieldOffset(56)] public string[] EventFeed = new string[64];
    }

    public class ExtendedSplitsModule : EverestModule
    {
        public static ExtendedSplitterInfo SplitterInfo = new ExtendedSplitterInfo();
        public static GCHandle Handle = GCHandle.Alloc(SplitterInfo, GCHandleType.Pinned);

        public static ExtendedSplitsModule Instance;

        public override Type SettingsType => typeof(ExtendedSplitsModuleSettings);
        public static ExtendedSplitsModuleSettings Settings => (ExtendedSplitsModuleSettings) Instance._Settings;

        public ExtendedSplitsModule()
        {
            Instance = this;
        }

        public void PushEvent(string e)
        {
            SplitterInfo.EventFeed[SplitterInfo.FeedIndex++ % SplitterInfo.EventFeed.Length] = e;
        }

        public override void Load()
        {
            On.Celeste.Celeste.Update += OnUpdate;
            On.Celeste.SaveData.SetCheckpoint += OnSetCheckpoint;
        }

        public override void Unload()
        {
            On.Celeste.Celeste.Update -= OnUpdate;
            On.Celeste.SaveData.SetCheckpoint -= OnSetCheckpoint;
        }

        private void OnUpdate(On.Celeste.Celeste.orig_Update orig, Celeste self, GameTime gametime)
        {
            orig(self, gametime);
            if (Engine.Scene is Level scene)
            {
                SplitterInfo.ChapterDeaths = scene.Session.Deaths;
                SplitterInfo.LevelDeaths = scene.Session.DeathsInCurrentLevel;
                var areaData = AreaData.Get(scene.Session);
                SplitterInfo.AreaName = areaData.Name;
                SplitterInfo.AreaSID = areaData.GetSID();
                SplitterInfo.LevelSet = areaData.GetLevelSet();
            }
            else
            {
                SplitterInfo.ChapterDeaths = 0;
                SplitterInfo.LevelDeaths = 0;
                SplitterInfo.AreaName = "";
                SplitterInfo.AreaSID = "";
                SplitterInfo.LevelSet = "";
            }
        }

        private bool OnSetCheckpoint(On.Celeste.SaveData.orig_SetCheckpoint orig, SaveData self, AreaKey area, string level)
        {
            PushEvent("checkpoint '" + level + "'");
            return orig(self, area, level);
        }
    }
}